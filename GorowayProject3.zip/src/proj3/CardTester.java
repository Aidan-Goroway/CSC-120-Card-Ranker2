package proj3;

public class CardTester {
    public static void main(String[] args) {
        Testing.startTests();
        testToString1();
        testToString2();
        testGetRank();
        testGetSuit();
        Testing.finishTests();

    }

    public static void testToString1(){
        Card threeClub = new Card(3,"Clubs");

        Testing.assertEquals("Tests toString of a 3 of Clubs"
        , "3 of Clubs"
        , threeClub.toString());
    }

    public static void testToString2(){
        Card aceSpades = new Card(14,"Spades");

        Testing.assertEquals("Tests toString of a Ace of Spades"
                , "Ace of Spades"
                , aceSpades.toString());
    }

    public static void testGetRank(){
        Card jackHearts = new Card(11,"Hearts");

        Testing.assertEquals("Tests toString of a Ace of Spades"
                , 11
                , jackHearts.getRank());
    }

    public static void testGetSuit(){
        Card nineDiamonds = new Card(9,"Diamonds");

        Testing.assertEquals("Tests toString of a Ace of Spades"
                , "Diamonds"
                , nineDiamonds.getSuit());
    }

}
