package proj3; // do not erase. Gradescope expects this.

import java.sql.Array;
import java.util.ArrayList;

public class PokerHand {

    private final int[] RANKS = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14};
    private final int HIGHEST_RANK = 14;
    private final int MAX_CARDS_IN_HAND = 5;
    private ArrayList<Card> cardList;

    /**
     * Constructor. models a hand of 5 playing cards.
     * @param cardList A list of cards that should be in the hand
     */
    public PokerHand(ArrayList<Card> cardList){
        this.cardList = cardList;
    }

    /**
     * Adds a card to the hand.
     * If the hand is full, does nothing.
     * @param CardObject The card that will be added.
     */
    public void addCard(Card CardObject){

        if (cardList.size() <= MAX_CARDS_IN_HAND){
            cardList.add(CardObject);
        }
        else {
            return;
        }

    }

    /**
     * Returns a card from the hand.
     * @param index The index of the card we are getting.
     * @return returns the card at the sepcified index.
     * If the index is invalid, returns nothing at all.
     */
    public Card get_ith_card(int index){

        if ((index >= 0) || (index < MAX_CARDS_IN_HAND)){
            return cardList.get(index);
        }
        else {
            return null;
        }

    }

    /**
     * Returns all the cards in a hand.
     * @return Returns an easily readable string of all the cards in a hand.
     */
    public String toString(){

        ArrayList<Card> handList = new ArrayList<>();
        for (int card=0; card<cardList.size(); card++){
            handList.add( cardList.get(card) );
        }

        return handList.toString();

    }

    /**
     * Determines how this hand compares to another hand, returns
     * positive, negative, or zero depending on the comparison.
     *
     * @param other The hand to compare this hand to
     * @return a negative number if this is worth LESS than other, zero
     * if they are worth the SAME, and a positive number if this is worth
     * MORE than other
     */
    public int compareTo(PokerHand other){

        PokerHand hand1 = PokerHand.this;
        PokerHand hand2 = other;

        // hand1 is greater
        if (hand1.determineIfFlush() && !hand2.determineIfFlush()){
            return 1;
        }
        if (hand1.determineIfTwoPair() &&
                (!hand2.determineIfFlush() && !hand2.determineIfTwoPair())){
            return 1;
        }
        if (hand1.determineIfPair() &&
                (!hand2.determineIfFlush() && !hand2.determineIfTwoPair() && !hand2.determineIfPair())){
            return 1;
        }

        // hand2 is greater
        if (hand2.determineIfFlush() &&
                !hand1.determineIfFlush()){
            return -1;
        }
        if (hand2.determineIfTwoPair() &&
                (!hand1.determineIfFlush() && !hand1.determineIfTwoPair())){
            return -1;
        }
        if (hand2.determineIfPair() &&
                (!hand1.determineIfFlush() && !hand1.determineIfTwoPair() && !hand1.determineIfPair())){
            return -1;
        }

        // both hands are the same type
        if ((hand1.determineIfFlush() && hand2.determineIfFlush()) || // flushes and HighCards
                ((hand1.determineIfHighCard() && hand2.determineIfHighCard()) &&
                        (!hand1.determineIfPair() && !hand2.determineIfPair()) &&
                        (!hand1.determineIfTwoPair() && !hand2.determineIfTwoPair()))){

            ArrayList<Integer> h1 = hand1.rankFlush();
            ArrayList<Integer> h2 = hand2.rankFlush();

            // systemiatically ranking flushes and highCards is the same

            for (int card = 0; card<h1.size(); card++){ // iterates through hands

                if (h1.get(card) > h2.get(card)){
                    return 1;
                }
                else if (h1.get(card) < h2.get(card)){
                    return -1;
                }
            }

            return 0;

        }

        if (hand1.determineIfTwoPair() && hand2.determineIfTwoPair()){ // twoPairs
            ArrayList<Integer> h1 = hand1.rankTwoPair();
            ArrayList<Integer> h2 = hand2.rankTwoPair();

            for (int card = 0; card<h1.size(); card++){ // iterates through hands
                if (h1.get(card) > h2.get(card)){
                    return 1;
                }
                else if (h1.get(card) < h2.get(card)){
                    return -1;
                }
            }

            return 0;

        }

        if (hand1.determineIfPair() && hand2.determineIfPair()){ // pairs
            ArrayList<Integer> h1 = hand1.rankPair();
            ArrayList<Integer> h2 = hand2.rankPair();

            for (int card = 0; card<h1.size(); card++){ // iterates through hands
                if (h1.get(card) > h2.get(card)){
                    return 1;
                }
                else if (h1.get(card) < h2.get(card)){
                    return -1;
                }
            }

            return 0;

        }

        return 999; // will not go off, here for syntax purposes

    }

    /**
     * Takes the a hand and extracts the ranks of all cards' ranks
     * @return Returns an ArrayList of integers in easily readable form.
     */
    private ArrayList<Integer> ranksOfHand(){

        ArrayList<Integer> rankList = new ArrayList<>();
        Card cardIndex;
        int card;

        for (int i = 0; i<MAX_CARDS_IN_HAND; i++){
            cardIndex = this.get_ith_card(i);
            card = cardIndex.getRank();
            rankList.add(card);
        }
        return rankList;
    }

    /**
     * Identifies a hand as a flush.
     * @return true or false, depending on if hand is a flush.
     */
    private boolean determineIfFlush(){

        Card card;
        String cardSuit;

        card = this.get_ith_card(0);
        cardSuit = card.getSuit(); // cardSuit; the suit of the first card in a hand
        for (int cardIndex=0; cardIndex<MAX_CARDS_IN_HAND; cardIndex++){ //iterates through a hand
            if (!cardSuit.equals(this.get_ith_card(cardIndex).getSuit())){
                return false;
            }
        }
        return true;
    }

    /**
     * Identifies a hand as a pair.
     * @return true or false, depending on if hand is a pair.
     */
    private boolean determineIfPair(){
        for (int i=0; i<MAX_CARDS_IN_HAND - 1; i++){
            for (int j=(i + 1); j<MAX_CARDS_IN_HAND; j++){
                 if (this.ranksOfHand().get(i).equals(this.ranksOfHand().get(j))){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Identifies a hand as a twoPair.
     * @return true or false, depending on if hand is a twoPair.
     */
    private boolean determineIfTwoPair() {
        int matchingCard1 = 0;
        int matchingCard2 = 0;
        boolean x = false;
        ArrayList<Integer> hand = new ArrayList<>();
        hand = this.ranksOfHand();

        for (int i = 0; i < MAX_CARDS_IN_HAND - 1; i++) {
            for (int j=(i + 1); j<MAX_CARDS_IN_HAND; j++) {
                if (this.ranksOfHand().get(i).equals(this.ranksOfHand().get(j))){
                    matchingCard1 = hand.get(i);
                    matchingCard2 = hand.get(j);
                    x = true;
                }
            }
        }
        if (x){
            hand.remove((Object) matchingCard1);
            hand.remove((Object) matchingCard2);
        }
        else {
            return false;
        }

        for (int i = 0; (i < hand.size() - 1); i++){ //2
            for (int j = (i + 1); (j < hand.size()); j++){ //3
                if (hand.get(i) == hand.get(j)){
                   hand.add(matchingCard1);
                    hand.add(matchingCard2);
                    return true;
                }
            }
        }
        hand.add(matchingCard1);
        hand.add(matchingCard2);
        return false;
    }

    /**
     * Identifies a highCard. Always goes off if none of the other card types
     * are identifed.
     * @return always returns true when ran.
     */
    private boolean determineIfHighCard(){
        return true;
    }

    /**
     * Only goes off when the hand is a flush.
     * @return returns the highest rank of a flush.
     */
    private ArrayList rankFlush(){

        ArrayList<Card> flush = new ArrayList<>();
        flush = this.cardList;
        ArrayList<Integer> ranksOfFlush = new ArrayList<>();

        for (int rank = HIGHEST_RANK; rank >= 0;rank--){ // backwards through RANKS
            for(int card = 0; card<flush.size(); card++){ // through each card in the flush
                Card cardToRank = flush.get(card);
                int cardRank = cardToRank.getRank();
                if (cardRank == rank){
                    ranksOfFlush.add(cardRank);
                }
            }
            if (ranksOfFlush.size() == MAX_CARDS_IN_HAND){ // for efficency purposes
                return ranksOfFlush;
            }
        }

        return null; // here for syntax purposes, will not go off.

    }

    /**
     * Only goes off when the hand is a pair.
     * @return Returns an arrayList of ints representing the hand's ranks.
     */
    private ArrayList<Integer> rankPair() {

       ArrayList<Integer> hand = new ArrayList<>();
       hand = this.ranksOfHand(); // our unmoddified hand

       ArrayList<Integer> rankList = new ArrayList<>(); // our new list of (int) ranks that we want to return
       int pairRank1 = 0;
       int pairRank2 = 0;

       for (int i = 0; i < MAX_CARDS_IN_HAND - 1; i++) {
           for (int j = (i + 1); j < MAX_CARDS_IN_HAND; j++) {
               if (this.ranksOfHand().get(i).equals(this.ranksOfHand().get(j))) { //pair detection
                   pairRank1 = hand.get(i);
                   pairRank2 = hand.get(j);
               }
           }
       }

        // append our pair's rank to rankList, & remove pair from the hand
       rankList.add(pairRank1);
       hand.remove((Object) pairRank1);
       hand.remove((Object) pairRank2);

       for (int rank = HIGHEST_RANK; rank >= 0;rank--){
            for (int card = 0; card<hand.size(); card++){
                int cardToRank = hand.get(card);
                if (cardToRank == rank){
                    rankList.add(cardToRank);
                }
            }
            if (rankList.size() == (MAX_CARDS_IN_HAND - 1)){ // for efficeincy purposes
                return rankList;
            }
       }

       return null; // will not go off, here for syntax purposes

   }

    /**
     * Only goes off when the hand is a pair.
     * @return Returns an arrayList of ints representing the hand's ranks.
     */
    private ArrayList<Integer> rankTwoPair(){

        ArrayList<Integer> hand = new ArrayList<>();
        hand = this.ranksOfHand(); // our unmoddified hand

        ArrayList<Integer> rankList = new ArrayList<>(); // our new list of (int) ranks that we want to return
        int pairRank1 = 0;
        int pairRank2 = 0;

        int pairRank3 = 0;
        int pairRank4 = 0;

        for (int i = 0; i < MAX_CARDS_IN_HAND - 1; i++) {
            for (int j = (i + 1); j < MAX_CARDS_IN_HAND; j++) {
                if (this.ranksOfHand().get(i).equals(this.ranksOfHand().get(j))) { //pair detection
                    pairRank1 = hand.get(i);
                    pairRank2 = hand.get(j);
                }
            }
        }

        rankList.add(pairRank1);
        hand.remove((Object) pairRank1);
        hand.remove((Object) pairRank2);

        for (int i = 0; i < (hand.size() - 1); i++){
            for (int j = (i + 1); j < hand.size(); j++){
                if (hand.get(i) == hand.get(j)){ // pair detection
                    pairRank3 = hand.get(i);
                    pairRank4 = hand.get(j);
                }
            }
        }

        if (rankList.get(0) > pairRank3){ // orders the two pair ranks
            rankList.add(pairRank3);
        }
        else {
            rankList.add(0, pairRank3);
        }

        hand.remove((Object) pairRank3);
        hand.remove((Object) pairRank4);
        rankList.add(hand.get(0));

        return rankList;

    }

    /**
     * Only goes off when the hand is a 'HighCard'.
     * @return Returns the highest Rank of the hand.
     */
    private ArrayList<Integer> rankHighCard(){

        ArrayList<Card> hand = new ArrayList<>();
        hand = this.cardList;
        ArrayList<Integer> ranksOfHighCard = new ArrayList<>();

        for (int rank = HIGHEST_RANK; rank >= 0; rank--){
            for (int card = 0; card<hand.size(); card++){
                Card cardToRank = hand.get(card);
                int cardRank = cardToRank.getRank();
                if (cardRank == rank){
                    ranksOfHighCard.add(cardRank);
                }
            }
            if (ranksOfHighCard.size() == MAX_CARDS_IN_HAND){ // for efficency purposes
                return ranksOfHighCard;
            }
        }
        return null; // here for syntax purposes, will not go off.
    }

}
