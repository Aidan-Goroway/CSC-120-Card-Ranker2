package proj3; // do not erase. Gradescope expects this.

public class Card {

    private final int DEFAULT_RANK = 14;
    private final String DEFAULT_SUIT = "Spades";

    private final String[] SUITS = {"Spades", "Clubs", "Diamonds", "Hearts"};

    private int rank;
    private String suit;

    /**
     * constructor: makes new card from given rank and suit
     *
     * @param rank int from 2-14
     * @param suit string ("Spades", "Clubs", "Diamonds", "Hearts")
     */
    public Card(int rank, String suit) {

        this.rank = rank;
        this.suit = suit;
    }

    /**
     *  default constructor (no parameters on constructor)
     */
    public Card() {
        this.rank = DEFAULT_RANK;
        this.suit = DEFAULT_SUIT;
    }

    /**
     * getter for rank
     * @return card's rank as integer: 2-14
     */
    public int getRank() {
        return rank;
    }

    /**
     * getter for suit
     * @return string (plural, starts with Capital letter)
     */
    public String getSuit() {
        return suit;
    }

    /**
     * converts numeric rank to string
     *
     * @return string version of rank like "4" or "Queen"
     */
    private String rank2String() {
        int myRank = getRank();
        if (myRank == 11) {
            return "Jack";
        }
        else if (myRank == 12) {
            return "Queen";
        }
        else if (myRank == 13) {
            return "King";
        }
        else if (myRank == 14) {
            return "Ace";
        }
        else {  // must be a whole number - just convert it to string
            return "" + myRank;
        }
    }

    /**
     * returns string version of Card
     *
     * @return string like "Jack of Clubs"
     */
    public String toString() {
        return rank2String() + " of " + getSuit();
    }

}