package proj3;

import java.util.ArrayList;
import java.util.Scanner;

public class Client {

    /**
     *The main function. Plays a game where a player is shown 2 randomized hands of playing cards.
     * If they can correctly choose which of the 2 hands is of greater value, they get a point.
     * The goal is to correctly choose until there are not enough cards in the deck (52) to create another
     * set of 2 hands. The game ends properly when this occurs, or prematurely when a guess is incorrect.
     */
    public static void main(String[] args){

        final int MAX_CARDS_IN_HAND = 5;
        int points = 0;
        String messageLoss = "Incorrect. Final points: " +  points;
        String messageWin = "You win! Final points: " + points;

        Deck newDeck = new Deck();
        newDeck.shuffle();

        ArrayList<Card> handOne = new ArrayList<>();
        PokerHand pokerHandOne = new PokerHand(handOne);

        ArrayList<Card> handTwo = new ArrayList<>();
        PokerHand pokerHandTwo = new PokerHand(handTwo);

        while (newDeck.size() > (MAX_CARDS_IN_HAND * 2)) {

            for (int CardToDeal = 0; CardToDeal < MAX_CARDS_IN_HAND; CardToDeal++) { //dealing loop
                Card card1 = newDeck.deal();
                pokerHandOne.addCard(card1);

                Card card2 = newDeck.deal();
                pokerHandTwo.addCard(card2);
            }

            int answer = pokerHandOne.compareTo(pokerHandTwo);

            System.out.println();
            System.out.println("Which of the following hands is more valuable?");
            System.out.println("Hand 1: " + pokerHandOne);
            System.out.println("Hand 2: " + pokerHandTwo);
            System.out.println("Answer \"1\" for Hand 1, or \"-1\" for Hand 2, or \"0\" if there is a tie.");
            Scanner scan = new Scanner(System.in);
            int guess = scan.nextInt();

            if (answer == guess) {
                points++;
            } else {
                System.out.println(messageLoss);
                return;
            }

            handOne.clear();
            handTwo.clear();

        }

        System.out.println(messageWin);

    }
}
