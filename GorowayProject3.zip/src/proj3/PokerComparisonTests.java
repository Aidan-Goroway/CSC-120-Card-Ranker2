package proj3;

/*
I affirm that I have carried out the attached academic endeavors with full academic honesty, in
accordance with the Union College Honor Code and the course syllabus.
 */

import java.util.ArrayList;

public class PokerComparisonTests {

    public static void main(String[] args) {
        //calls go here
        //CHECK VERBOSITY BOOLEAN IN TESTING//

        Testing.startTests();
        testCompareToHC1();
        testCompareTo2Flushes1();
        testCompareTo2Pairs1();
        testCompareTo2TwoPairs1();
        testCompareTo2Pairs2();
        testCompareTo2twoPairs2();
        Testing.finishTests();

    }
        //methods go here

    public static void testCompareToHC1(){
        Card c1 = new Card(11,"Hearts");
        Card c2 = new Card(7,"Hearts");
        Card c3 = new Card(14,"Hearts");
        Card c4 = new Card(9,"Diamonds");
        Card c5 = new Card(3,"Hearts");
        ArrayList<Card> array1 = new ArrayList<>();
        array1.add(c1);
        array1.add(c2);
        array1.add(c3);
        array1.add(c4);
        array1.add(c5);
        PokerHand hand1 = new PokerHand(array1);

        Card d1 = new Card(8,"Spades");
        Card d2 = new Card(7,"Diamonds");
        Card d3 = new Card(13,"Diamonds");
        Card d4 = new Card(12,"Diamonds");
        Card d5 = new Card(9,"Diamonds");
        ArrayList<Card> array2 = new ArrayList<>();
        array2.add(d1);
        array2.add(d2);
        array2.add(d3);
        array2.add(d4);
        array2.add(d5);
        PokerHand hand2 = new PokerHand(array2);

        Testing.assertEquals("Tests for 2 highCards"
                , 1
                , hand1.compareTo(hand2));
    }

    public static void testCompareTo2Flushes1(){
        Card c1 = new Card(14,"Hearts");
        Card c2 = new Card(12,"Hearts");
        Card c3 = new Card(12,"Hearts");
        Card c4 = new Card(11,"Hearts");
        Card c5 = new Card(7,"Hearts");
        ArrayList<Card> array1 = new ArrayList<>();
        array1.add(c1);
        array1.add(c2);
        array1.add(c3);
        array1.add(c4);
        array1.add(c5);
        PokerHand hand1 = new PokerHand(array1);

        Card d1 = new Card(14,"Diamonds");
        Card d2 = new Card(12,"Diamonds");
        Card d3 = new Card(9,"Diamonds");
        Card d4 = new Card(9,"Diamonds");
        Card d5 = new Card(13,"Diamonds");
        ArrayList<Card> array2 = new ArrayList<>();
        array2.add(d1);
        array2.add(d2);
        array2.add(d3);
        array2.add(d4);
        array2.add(d5);
        PokerHand hand2 = new PokerHand(array2);

        Testing.assertEquals("Tests 2 flushes for the 2nd highest card"
                , -1
                , hand1.compareTo(hand2));
    }


    public static void testCompareTo2Pairs1(){
        Card c1 = new Card(12,"Hearts");
        Card c2 = new Card(12,"Diamonds");
        Card c3 = new Card(6,"Hearts");
        Card c4 = new Card(5,"Hearts");
        Card c5 = new Card(3,"Hearts");
        ArrayList<Card> array1 = new ArrayList<>();
        array1.add(c1);
        array1.add(c2);
        array1.add(c3);
        array1.add(c4);
        array1.add(c5);
        PokerHand hand1 = new PokerHand(array1);

        Card d1 = new Card(11,"Hearts");
        Card d2 = new Card(11,"Diamonds");
        Card d3 = new Card(9,"Diamonds");
        Card d4 = new Card(8,"Diamonds");
        Card d5 = new Card(7,"Diamonds");
        ArrayList<Card> array2 = new ArrayList<>();
        array2.add(d1);
        array2.add(d2);
        array2.add(d3);
        array2.add(d4);
        array2.add(d5);
        PokerHand hand2 = new PokerHand(array2);

        Testing.assertEquals("Tests CompareTo for a pair of queens vs a pair of jacks"
                , 1
                , hand1.compareTo(hand2));
    }

    public static void testCompareTo2TwoPairs1(){
        Card c1 = new Card(10,"Hearts");
        Card c2 = new Card(10,"Diamonds");
        Card c3 = new Card(8,"Hearts");
        Card c4 = new Card(8,"Hearts");
        Card c5 = new Card(3,"Hearts");
        ArrayList<Card> array1 = new ArrayList<>();
        array1.add(c1);
        array1.add(c2);
        array1.add(c3);
        array1.add(c4);
        array1.add(c5);
        PokerHand hand1 = new PokerHand(array1);

        Card d1 = new Card(10,"Hearts");
        Card d2 = new Card(10,"Diamonds");
        Card d3 = new Card(6,"Diamonds");
        Card d4 = new Card(6,"Diamonds");
        Card d5 = new Card(7,"Diamonds");
        ArrayList<Card> array2 = new ArrayList<>();
        array2.add(d1);
        array2.add(d2);
        array2.add(d3);
        array2.add(d4);
        array2.add(d5);
        PokerHand hand2 = new PokerHand(array2);

        Testing.assertEquals("Tests CompareTo for a twopair of 10s vs a twopair of 8s"
                , 1
                , hand1.compareTo(hand2));
    }

    public static void testCompareTo2Pairs2(){
        Card c1 = new Card(10,"Hearts");
        Card c2 = new Card(10,"Diamonds");
        Card c3 = new Card(13,"Hearts");
        Card c4 = new Card(8,"Hearts");
        Card c5 = new Card(3,"Hearts");
        ArrayList<Card> array1 = new ArrayList<>();
        array1.add(c1);
        array1.add(c2);
        array1.add(c3);
        array1.add(c4);
        array1.add(c5);
        PokerHand hand1 = new PokerHand(array1);

        Card d1 = new Card(10,"Hearts");
        Card d2 = new Card(10,"Diamonds");
        Card d3 = new Card(11,"Diamonds");
        Card d4 = new Card(6,"Diamonds");
        Card d5 = new Card(7,"Diamonds");
        ArrayList<Card> array2 = new ArrayList<>();
        array2.add(d1);
        array2.add(d2);
        array2.add(d3);
        array2.add(d4);
        array2.add(d5);
        PokerHand hand2 = new PokerHand(array2);

        Testing.assertEquals("Tests for 2 pairs that break tie with their first chaser"
                , 1
                , hand1.compareTo(hand2));
    }

    public static void testCompareTo2twoPairs2(){
        Card c1 = new Card(14,"Hearts");
        Card c2 = new Card(14,"Diamonds");
        Card c3 = new Card(7,"Hearts");
        Card c4 = new Card(7,"Hearts");
        Card c5 = new Card(3,"Hearts");
        ArrayList<Card> array1 = new ArrayList<>();
        array1.add(c1);
        array1.add(c2);
        array1.add(c3);
        array1.add(c4);
        array1.add(c5);
        PokerHand hand1 = new PokerHand(array1);

        Card d1 = new Card(14,"Spades");
        Card d2 = new Card(14,"Clubs");
        Card d3 = new Card(7,"Diamonds");
        Card d4 = new Card(7,"Diamonds");
        Card d5 = new Card(7,"Diamonds");
        ArrayList<Card> array2 = new ArrayList<>();
        array2.add(d1);
        array2.add(d2);
        array2.add(d3);
        array2.add(d4);
        array2.add(d5);
        PokerHand hand2 = new PokerHand(array2);

        Testing.assertEquals("Tests for 2 twoPairs that break tie with their last chaser"
                , -1
                , hand1.compareTo(hand2));
    }

}
