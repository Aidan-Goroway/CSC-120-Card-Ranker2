package proj3;

public class DeckTester {

    //Deck is constructed by RANK 2-14, Spa-Clu-Dia-Hea pattern for each.
    public static void main(String[] args) {
        Testing.startTests();
        testToString();
        testToStringLast3();
        testShuffle();
        Testing.finishTests();
    }

    public static void testToString(){
        Deck deck1 = new Deck();
        final int CARDS_TO_SKIP = 0;
        for (int x = 0; x<CARDS_TO_SKIP; x++){
            deck1.deal();
        }
        Testing.assertEquals("Tests a printout of the entire deck"
                ,"The entire deck, Spades->Clubs->Diamonds->Hearts for ranks 2-Ace"
                , deck1.toString());
    }

    public static void testToStringLast3(){
        Deck deck1 = new Deck();
        final int CARDS_TO_SKIP = 49;
        for (int x = 0; x<CARDS_TO_SKIP; x++){
            deck1.deal();
        }
        Testing.assertEquals("Tests a printout of the last 3 cards of the deck"
        ,"[Ace of Clubs, Ace of Diamonds, Ace of Hearts]"
                , deck1.toString());
    }

    public static void testShuffle(){
        Deck deck1 = new Deck();
        final int CARDS_TO_SKIP = 0;
        for (int x = 0; x<CARDS_TO_SKIP; x++){
            deck1.deal();
        }
        deck1.shuffle();
        Testing.assertEquals("Tests a printout of the entire deck, shuffled"
                ,"52 cards in random order"
                , deck1.toString());
    }

}
